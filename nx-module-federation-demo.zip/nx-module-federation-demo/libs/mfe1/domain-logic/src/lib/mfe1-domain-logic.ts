export function mfe1DomainLogic(): string {
  return 'mfe1-domain-logic';
}
