import { mfe1DomainLogic } from './mfe1-domain-logic';

describe('mfe1DomainLogic', () => {
  it('should work', () => {
    expect(mfe1DomainLogic()).toEqual('mfe1-domain-logic');
  });
});
