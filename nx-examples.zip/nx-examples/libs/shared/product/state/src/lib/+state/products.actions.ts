import { Action } from '@ngrx/store';

export enum ProductsActionTypes {}

export type ProductsAction = Action;
