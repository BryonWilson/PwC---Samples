# shared-util-common

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test shared-util-common` to execute the unit tests.
