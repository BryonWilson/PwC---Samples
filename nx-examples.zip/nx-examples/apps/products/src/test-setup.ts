import 'jest-preset-angular/setup-jest';

import 'document-register-element';
