# shared-ui-shell

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test shared-ui-shell` to execute the unit tests.
