# mfe1-domain-logic

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test mfe1-domain-logic` to execute the unit tests via [Jest](https://jestjs.io).

## Running lint

Run `nx lint mfe1-domain-logic` to execute the lint via [ESLint](https://eslint.org/).
