export function authLib(): string {
  return 'auth-lib';
}
