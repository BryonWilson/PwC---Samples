import { authLib } from './auth-lib';

describe('authLib', () => {
  it('should work', () => {
    expect(authLib()).toEqual('auth-lib');
  });
});
