# products-product-detail-page

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `ng test products-product-detail-page` to execute the unit tests.
