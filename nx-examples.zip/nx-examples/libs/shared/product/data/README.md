# shared-product-data

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `ng test shared-product-data` to execute the unit tests via [Jest](https://jestjs.io).
