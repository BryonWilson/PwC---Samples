export const environment = {
  production: true,
  moduleFederationUrl: {
    app1: 'https://module-federation-app1.web.app/',
    app2: 'https://module-federation-app2.web.app/',
    app3: 'https://module-federation-app3.web.app/'
  }
};
