export * from './lib/mfe1-domain-logic';
