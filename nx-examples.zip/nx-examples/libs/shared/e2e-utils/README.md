# shared-e2e-utils

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `ng test shared-product-e2e-utils` to execute the unit tests via [Jest](https://jestjs.io).
