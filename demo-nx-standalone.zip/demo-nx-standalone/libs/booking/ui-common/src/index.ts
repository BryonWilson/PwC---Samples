export * from './lib/flight-card/flight-card.component';
