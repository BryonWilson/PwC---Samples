import { Component } from "@angular/core";

@Component({
  standalone: true,
  selector: 'app-passenger-search',
  templateUrl: './passenger-search.component.html',
})
export class PassengerSearchComponent {
}
