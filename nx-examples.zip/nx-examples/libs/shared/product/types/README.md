# shared-product-types

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `ng test shared-product-types` to execute the unit tests via [Jest](https://jestjs.io).
