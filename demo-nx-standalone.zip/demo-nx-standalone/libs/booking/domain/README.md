# booking-domain

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test booking-domain` to execute the unit tests.
