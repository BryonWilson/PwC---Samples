/**
 * This file contains polyfills loaded on all browsers
 **/
