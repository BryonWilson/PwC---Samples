export const getPage = () => cy.get('#root');
